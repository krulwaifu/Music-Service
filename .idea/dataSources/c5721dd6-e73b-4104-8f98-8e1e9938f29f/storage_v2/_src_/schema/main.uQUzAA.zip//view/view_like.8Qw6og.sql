CREATE VIEW view_like as
	select * from audio_liked;

